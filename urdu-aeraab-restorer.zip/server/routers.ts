import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { diacritizationRouter } from "./routers/diacritization";
import { historyRouter } from "./routers/history";
import { exportRouter } from "./routers/export";
import { batchRouter } from "./routers/batch";
import { analyticsRouter } from "./routers/analytics";
import { ratingsRouter } from "./routers/ratings";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  diacritization: diacritizationRouter,
  history: historyRouter,
  export: exportRouter,
  batch: batchRouter,
  analytics: analyticsRouter,
  ratings: ratingsRouter,
});

export type AppRouter = typeof appRouter;
