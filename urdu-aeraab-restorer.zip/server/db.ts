import { eq, desc, and, avg, count } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, DiacritizationResult, InsertDiacritizationResult, diacritizationResults, sessionHistory, batchJobs, BatchJob, InsertBatchJob, resultRatings } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Create a new diacritization result
 */
export async function createDiacritizationResult(data: InsertDiacritizationResult) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(diacritizationResults).values(data);
  return result;
}

/**
 * Get a diacritization result by ID
 */
export async function getDiacritizationResultById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(diacritizationResults)
    .where(eq(diacritizationResults.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get user's diacritization history with pagination
 */
export async function getUserDiacritizationHistory(
  userId: number,
  limit: number = 50,
  offset: number = 0
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const results = await db
    .select()
    .from(diacritizationResults)
    .where(eq(diacritizationResults.userId, userId))
    .orderBy((t) => t.createdAt)
    .limit(limit)
    .offset(offset);

  return results;
}

/**
 * Delete a diacritization result
 */
export async function deleteDiacritizationResult(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(diacritizationResults).where(eq(diacritizationResults.id, id));
}

/**
 * Add result to session history
 */
export async function addToSessionHistory(
  userId: number,
  resultId: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(sessionHistory).values({
    userId,
    resultId,
  });
}

/**
 * Create a new batch job
 */
export async function createBatchJob(job: InsertBatchJob) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(batchJobs).values(job);
  return result;
}

/**
 * Get batch job by ID
 */
export async function getBatchJob(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(batchJobs)
    .where(and(eq(batchJobs.id, id), eq(batchJobs.userId, userId)))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Get user's batch jobs with pagination
 */
export async function getUserBatchJobs(
  userId: number,
  limit: number = 20,
  offset: number = 0
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(batchJobs)
    .where(eq(batchJobs.userId, userId))
    .orderBy((t) => desc(t.createdAt))
    .limit(limit)
    .offset(offset);
}

/**
 * Update batch job status
 */
export async function updateBatchJobStatus(
  id: number,
  status: string,
  processedItems?: number,
  resultsUrl?: string,
  errorMessage?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status, updatedAt: new Date() };
  if (processedItems !== undefined) {
    updateData.processedItems = processedItems;
  }
  if (resultsUrl !== undefined) {
    updateData.resultsUrl = resultsUrl;
  }
  if (errorMessage !== undefined) {
    updateData.errorMessage = errorMessage;
  }
  if (status === "completed") {
    updateData.completedAt = new Date();
  }

  await db.update(batchJobs).set(updateData).where(eq(batchJobs.id, id));
}

/**
 * Get analytics statistics for a user
 */
export async function getAnalyticsStats(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const results = await db
    .select()
    .from(diacritizationResults)
    .where(eq(diacritizationResults.userId, userId));

  if (results.length === 0) {
    return {
      avgConfidence: 0,
      avgProcessingTime: 0,
      totalProcessed: 0,
      minConfidence: 0,
      maxConfidence: 0,
    };
  }

  const confidenceScores = results.map((r) => r.confidenceScore);
  const processingTimes = results.map((r) => r.processingTimeMs);

  const avgConfidence = Math.round(
    confidenceScores.reduce((a, b) => a + b, 0) / confidenceScores.length
  );
  const avgProcessingTime = Math.round(
    processingTimes.reduce((a, b) => a + b, 0) / processingTimes.length
  );

  return {
    avgConfidence,
    avgProcessingTime,
    totalProcessed: results.length,
    minConfidence: Math.min(...confidenceScores),
    maxConfidence: Math.max(...confidenceScores),
  };
}

/**
 * Clear all user's diacritization history
 */
export async function clearUserHistory(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.delete(diacritizationResults).where(eq(diacritizationResults.userId, userId));
}


export async function createRating(
  resultId: number,
  userId: number,
  rating: number,
  feedback?: string
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db.insert(resultRatings).values({
    resultId,
    userId,
    rating,
    feedback,
  });
}

export async function getResultRating(resultId: number, userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(resultRatings)
    .where(
      and(
        eq(resultRatings.resultId, resultId),
        eq(resultRatings.userId, userId)
      )
    )
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function updateRating(
  resultId: number,
  userId: number,
  rating: number,
  feedback?: string
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  await db
    .update(resultRatings)
    .set({ rating, feedback, updatedAt: new Date() })
    .where(
      and(
        eq(resultRatings.resultId, resultId),
        eq(resultRatings.userId, userId)
      )
    );
}

export async function getAverageRating(resultId: number) {
  const db = await getDb();
  if (!db) return 0;

  const result = await db
    .select({ avgRating: avg(resultRatings.rating) })
    .from(resultRatings)
    .where(eq(resultRatings.resultId, resultId));

  return result[0]?.avgRating ? Math.round(Number(result[0].avgRating) * 10) / 10 : 0;
}

export async function getRatingDistribution(userId: number) {
  const db = await getDb();
  if (!db) return { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };

  const ratings = await db
    .select({ rating: resultRatings.rating, cnt: count() })
    .from(resultRatings)
    .innerJoin(
      diacritizationResults,
      eq(resultRatings.resultId, diacritizationResults.id)
    )
    .where(eq(diacritizationResults.userId, userId))
    .groupBy(resultRatings.rating);

  const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  ratings.forEach((r) => {
    distribution[r.rating as keyof typeof distribution] = r.cnt;
  });

  return distribution;
}
