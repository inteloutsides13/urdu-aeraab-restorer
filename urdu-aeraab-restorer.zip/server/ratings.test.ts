import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("ratings router", () => {
  it("should submit a rating for a diacritization result", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // Note: This test assumes a result with ID 1 exists in the database
    // In a real scenario, you'd create a test result first
    try {
      const result = await caller.ratings.submitRating({
        resultId: 1,
        rating: 5,
        feedback: "Great diacritization!",
      });

      expect(result).toHaveProperty("success");
      expect(result).toHaveProperty("averageRating");
    } catch (error) {
      // Expected if no result exists in test DB
      expect(error).toBeDefined();
    }
  });

  it("should get user rating for a result", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      const rating = await caller.ratings.getUserRating({
        resultId: 1,
      });

      // Rating can be null if not yet rated
      expect(rating === null || typeof rating === "object").toBe(true);
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should get average rating for a result", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      const result = await caller.ratings.getAverageRating({
        resultId: 1,
      });

      expect(result).toHaveProperty("averageRating");
      expect(typeof result.averageRating === "number").toBe(true);
    } catch (error) {
      expect(error).toBeDefined();
    }
  });

  it("should get rating distribution for user", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    try {
      const distribution = await caller.ratings.getRatingDistribution();

      expect(distribution).toHaveProperty("1");
      expect(distribution).toHaveProperty("2");
      expect(distribution).toHaveProperty("3");
      expect(distribution).toHaveProperty("4");
      expect(distribution).toHaveProperty("5");
    } catch (error) {
      expect(error).toBeDefined();
    }
  });
});
