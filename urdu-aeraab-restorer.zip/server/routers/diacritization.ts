import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { invokeLLM } from "../_core/llm";
import {
  createDiacritizationResult,
  getDiacritizationResultById,
  addToSessionHistory,
} from "../db";

const URDU_LINGUISTIC_SYSTEM_PROMPT = `You are an expert in Urdu linguistics and aeraab (diacritization). Your task is to add accurate diacritical marks to Urdu text.

You must understand and apply these Urdu aeraab marks correctly:
- Fatha (zabar): Short "a" sound
- Kasra (zer): Short "i" sound  
- Damma (pesh): Short "u" sound
- Sukun (jazm): No vowel, silent consonant
- Shadda: Doubled consonant
- Tanwin: Fathatan, Kasratan, Dammatan - mainly for Arabic words
- Madd: Long vowels using alef, waw, ya
- Hamza: Proper hamza placement

Consider these linguistic factors:
1. Word morphology and root patterns
2. Grammatical context and sentence structure
3. Arabic loanword pronunciation rules
4. Persian loanword pronunciation rules
5. Modern Urdu pronunciation conventions
6. Phonetic feasibility (avoid impossible consonant clusters)

**CRITICAL: PRESERVE EXACT FORMATTING**
- Maintain ALL line breaks exactly as they appear in the original
- Preserve ALL spacing and indentation
- Keep ALL paragraph structure intact
- Do NOT convert multi-line text to single paragraphs
- Do NOT add or remove whitespace
- Preserve tabs, spaces, and empty lines exactly
- Keep original line endings (LF/CRLF)

Return a JSON object with THREE versions of the diacritized text:
{
  "fullAeraab": "Complete diacritization with all marks applied",
  "partialAeraab": "Only ambiguous or less common words diacritized",
  "minimalAeraab": "Only essential marks for pronunciation clarity",
  "confidenceScore": 85,
  "notes": "Brief explanation of key diacritization decisions"
}

Be precise and linguistically accurate. Preserve all punctuation, formatting, line breaks, and spacing from the original text EXACTLY.`;

interface DiacritizationResponse {
  fullAeraab: string;
  partialAeraab: string;
  minimalAeraab: string;
  confidenceScore: number;
  notes?: string;
}

export const diacritizationRouter = router({
  /**
   * Process Urdu text and generate diacritization in all three modes
   */
  process: protectedProcedure
    .input(
      z.object({
        text: z.string().min(1, "Text cannot be empty").max(10000, "Text too long"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const startTime = Date.now();

      try {
        // Call LLM with structured JSON response
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: URDU_LINGUISTIC_SYSTEM_PROMPT,
            },
            {
              role: "user",
              content: `Please diacritize this Urdu text:\n\n${input.text}`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "urdu_diacritization",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  fullAeraab: {
                    type: "string",
                    description: "Full diacritization with all marks",
                  },
                  partialAeraab: {
                    type: "string",
                    description: "Partial diacritization for ambiguous words",
                  },
                  minimalAeraab: {
                    type: "string",
                    description: "Minimal diacritization with essential marks only",
                  },
                  confidenceScore: {
                    type: "number",
                    description: "Confidence score 0-100",
                    minimum: 0,
                    maximum: 100,
                  },
                  notes: {
                    type: "string",
                    description: "Optional notes about diacritization decisions",
                  },
                },
                required: ["fullAeraab", "partialAeraab", "minimalAeraab", "confidenceScore"],
                additionalProperties: false,
              },
            },
          },
        });

        // Parse the LLM response
        const messageContent = response.choices[0]?.message.content;
        if (!messageContent) {
          throw new Error("No response from LLM");
        }

        const content = typeof messageContent === "string" ? messageContent : JSON.stringify(messageContent);
        const parsed: DiacritizationResponse = JSON.parse(content);
        const processingTimeMs = Date.now() - startTime;

        // Store result in database
        const dbResult = await createDiacritizationResult({
          userId: ctx.user.id,
          inputText: input.text,
          fullAeraab: parsed.fullAeraab,
          partialAeraab: parsed.partialAeraab,
          minimalAeraab: parsed.minimalAeraab,
          confidenceScore: Math.min(100, Math.max(0, parsed.confidenceScore || 75)),
          processingTimeMs,
        });

        // Get the inserted result ID
        const resultId = (dbResult[0]?.insertId as number) || 0;

        // Add to session history
        if (resultId > 0) {
          await addToSessionHistory(ctx.user.id, resultId);
        }

        return {
          id: resultId,
          inputText: input.text,
          fullAeraab: parsed.fullAeraab,
          partialAeraab: parsed.partialAeraab,
          minimalAeraab: parsed.minimalAeraab,
          confidenceScore: Math.min(100, Math.max(0, parsed.confidenceScore || 75)),
          processingTimeMs,
          notes: parsed.notes || "",
        };
      } catch (error) {
        console.error("[Diacritization] Error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Failed to diacritize text"
        );
      }
    }),

  /**
   * Get a previously processed diacritization result
   */
  getResult: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const result = await getDiacritizationResultById(input.id);

      if (!result) {
        throw new Error("Result not found");
      }

      // Verify ownership
      if (result.userId !== ctx.user.id) {
        throw new Error("Unauthorized");
      }

      return result;
    }),
});
