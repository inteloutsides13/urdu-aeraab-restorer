import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDiacritizationResultById } from "../db";

export const exportRouter = router({
  /**
   * Export diacritization result as plain text
   */
  toPlainText: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        mode: z.enum(["full", "partial", "minimal"]).default("full"),
      })
    )
    .query(async ({ ctx, input }) => {
      const result = await getDiacritizationResultById(input.id);

      if (!result) {
        throw new Error("Result not found");
      }

      if (result.userId !== ctx.user.id) {
        throw new Error("Unauthorized");
      }

      let textContent = "";
      if (input.mode === "full") {
        textContent = result.fullAeraab;
      } else if (input.mode === "partial") {
        textContent = result.partialAeraab;
      } else {
        textContent = result.minimalAeraab;
      }

      return {
        content: textContent,
        filename: `urdu-aeraab-${input.mode}-${Date.now()}.txt`,
        mimeType: "text/plain",
      };
    }),

  /**
   * Export diacritization result as HTML
   */
  toHtml: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        mode: z.enum(["full", "partial", "minimal"]).default("full"),
      })
    )
    .query(async ({ ctx, input }) => {
      const result = await getDiacritizationResultById(input.id);

      if (!result) {
        throw new Error("Result not found");
      }

      if (result.userId !== ctx.user.id) {
        throw new Error("Unauthorized");
      }

      let textContent = "";
      if (input.mode === "full") {
        textContent = result.fullAeraab;
      } else if (input.mode === "partial") {
        textContent = result.partialAeraab;
      } else {
        textContent = result.minimalAeraab;
      }

      const htmlContent = `<!DOCTYPE html>
<html dir="rtl" lang="ur">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Urdu Aeraab - ${input.mode} Mode</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Noto Nastaliq Urdu', serif;
            direction: rtl;
            background-color: #f5f5f5;
            padding: 2rem;
            line-height: 2;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 2rem;
            border-bottom: 2px solid #e0e0e0;
            padding-bottom: 1rem;
        }
        .header h1 {
            margin: 0;
            color: #333;
            font-size: 1.8rem;
        }
        .mode-badge {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            font-size: 0.9rem;
            margin-top: 0.5rem;
        }
        .content {
            font-size: 1.3rem;
            color: #333;
            white-space: pre;
            word-wrap: break-word;
            overflow-x: auto;
            background-color: #f9f9f9;
            padding: 1rem;
            border-radius: 4px;
            border-left: 4px solid #007bff;
        }
        .metadata {
            margin-top: 2rem;
            padding-top: 1rem;
            border-top: 1px solid #e0e0e0;
            font-size: 0.9rem;
            color: #666;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>اردو اعراب</h1>
            <p>Urdu Aeraab Diacritization</p>
            <span class="mode-badge">${input.mode.toUpperCase()} Mode</span>
        </div>
        <pre class="content">${textContent.replace(/</g, "&lt;").replace(/>/g, "&gt;")}</pre>
        <div class="metadata">
            <p>Generated on: ${new Date().toLocaleString("ur-PK")}</p>
            <p>Confidence Score: ${result.confidenceScore}%</p>
            <p>Processing Time: ${result.processingTimeMs}ms</p>
        </div>
    </div>
</body>
</html>`;

      return {
        content: htmlContent,
        filename: `urdu-aeraab-${input.mode}-${Date.now()}.html`,
        mimeType: "text/html",
      };
    }),
});
