import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { createBatchJob, getUserBatchJobs, getBatchJob, updateBatchJobStatus } from "../db";
import { TRPCError } from "@trpc/server";

export const batchRouter = router({
  /**
   * Upload and create a batch job
   */
  upload: protectedProcedure
    .input(
      z.object({
        filename: z.string().min(1).max(255),
        totalItems: z.number().int().positive(),
        fileUrl: z.string().url().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const result = await createBatchJob({
          userId: ctx.user.id,
          filename: input.filename,
          totalItems: input.totalItems,
          fileUrl: input.fileUrl,
          status: "pending",
        });

        return {
          id: (result as any).insertId || 0,
          filename: input.filename,
          totalItems: input.totalItems,
          status: "pending",
          createdAt: new Date(),
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create batch job",
        });
      }
    }),

  /**
   * Get user's batch jobs
   */
  list: protectedProcedure
    .input(
      z.object({
        limit: z.number().int().positive().default(20),
        offset: z.number().int().nonnegative().default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const jobs = await getUserBatchJobs(ctx.user.id, input.limit, input.offset);
        return jobs.map((job) => ({
          id: job.id,
          filename: job.filename,
          totalItems: job.totalItems,
          processedItems: job.processedItems,
          status: job.status,
          createdAt: job.createdAt,
          completedAt: job.completedAt,
          resultsUrl: job.resultsUrl,
          progress: job.totalItems > 0 ? Math.round((job.processedItems / job.totalItems) * 100) : 0,
        }));
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch batch jobs",
        });
      }
    }),

  /**
   * Get batch job details
   */
  get: protectedProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ ctx, input }) => {
      try {
        const job = await getBatchJob(input.id, ctx.user.id);
        if (!job) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Batch job not found",
          });
        }

        return {
          id: job.id,
          filename: job.filename,
          totalItems: job.totalItems,
          processedItems: job.processedItems,
          status: job.status,
          createdAt: job.createdAt,
          completedAt: job.completedAt,
          resultsUrl: job.resultsUrl,
          errorMessage: job.errorMessage,
          progress: job.totalItems > 0 ? Math.round((job.processedItems / job.totalItems) * 100) : 0,
        };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch batch job",
        });
      }
    }),

  /**
   * Update batch job progress (internal use)
   */
  updateProgress: protectedProcedure
    .input(
      z.object({
        id: z.number().int().positive(),
        processedItems: z.number().int().nonnegative(),
        status: z.enum(["pending", "processing", "completed", "failed"]).optional(),
        resultsUrl: z.string().url().optional(),
        errorMessage: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const job = await getBatchJob(input.id, ctx.user.id);
        if (!job) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Batch job not found",
          });
        }

        await updateBatchJobStatus(
          input.id,
          input.status || job.status,
          input.processedItems,
          input.resultsUrl,
          input.errorMessage
        );

        return { success: true };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update batch job",
        });
      }
    }),
});
