import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getUserDiacritizationHistory, deleteDiacritizationResult, clearUserHistory } from "../db";

export const historyRouter = router({
  /**
   * Get user's diacritization history with pagination
   */
  list: protectedProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(50),
        offset: z.number().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const results = await getUserDiacritizationHistory(
        ctx.user.id,
        input.limit,
        input.offset
      );

      return results.map((r) => ({
        id: r.id,
        inputText: r.inputText,
        fullAeraab: r.fullAeraab,
        partialAeraab: r.partialAeraab,
        minimalAeraab: r.minimalAeraab,
        confidenceScore: r.confidenceScore,
        processingTimeMs: r.processingTimeMs,
        createdAt: r.createdAt,
      }));
    }),

  /**
   * Delete a diacritization result from history
   */
  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      // Verify ownership first
      const result = await getUserDiacritizationHistory(ctx.user.id, 1000, 0);
      const owned = result.some((r) => r.id === input.id);

      if (!owned) {
        throw new Error("Unauthorized");
      }

      await deleteDiacritizationResult(input.id);

      return { success: true };
    }),

  /**
   * Clear all user's diacritization history
   */
  clearAll: protectedProcedure.mutation(async ({ ctx }) => {
    await clearUserHistory(ctx.user.id);
    return { success: true };
  }),
});
