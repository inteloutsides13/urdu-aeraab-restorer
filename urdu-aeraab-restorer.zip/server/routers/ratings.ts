import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createRating,
  getResultRating,
  updateRating,
  getAverageRating,
  getRatingDistribution,
} from "../db";
import { TRPCError } from "@trpc/server";

export const ratingsRouter = router({
  /**
   * Submit or update a rating for a diacritization result
   */
  submitRating: protectedProcedure
    .input(
      z.object({
        resultId: z.number(),
        rating: z.number().min(1).max(5),
        feedback: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const existingRating = await getResultRating(input.resultId, ctx.user.id);

        if (existingRating) {
          await updateRating(input.resultId, ctx.user.id, input.rating, input.feedback);
        } else {
          await createRating(input.resultId, ctx.user.id, input.rating, input.feedback);
        }

        const avgRating = await getAverageRating(input.resultId);

        return {
          success: true,
          averageRating: avgRating,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to submit rating",
        });
      }
    }),

  /**
   * Get user's rating for a specific result
   */
  getUserRating: protectedProcedure
    .input(
      z.object({
        resultId: z.number(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const rating = await getResultRating(input.resultId, ctx.user.id);
        return rating || null;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch rating",
        });
      }
    }),

  /**
   * Get average rating for a result
   */
  getAverageRating: protectedProcedure
    .input(
      z.object({
        resultId: z.number(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const avgRating = await getAverageRating(input.resultId);
        return { averageRating: avgRating };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch average rating",
        });
      }
    }),

  /**
   * Get user's rating distribution
   */
  getRatingDistribution: protectedProcedure.query(async ({ ctx }) => {
    try {
      const distribution = await getRatingDistribution(ctx.user.id);
      return distribution;
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to fetch rating distribution",
      });
    }
  }),
});
