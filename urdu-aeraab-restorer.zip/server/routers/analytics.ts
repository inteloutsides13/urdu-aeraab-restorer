import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getAnalyticsStats, getUserDiacritizationHistory } from "../db";
import { TRPCError } from "@trpc/server";

export const analyticsRouter = router({
  /**
   * Get user's analytics statistics with filtering
   */
  getStats: protectedProcedure
    .input(
      z.object({
        dateFrom: z.number().optional(),
        dateTo: z.number().optional(),
        confidenceThreshold: z.number().min(0).max(100).default(0),
        mode: z.enum(["full", "partial", "minimal"]).optional(),
        processingTimeMin: z.number().min(0).default(0),
        processingTimeMax: z.number().min(0).default(10000),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const history = await getUserDiacritizationHistory(ctx.user.id, 1000, 0);

        // Apply filters
        let filtered = history.filter((item) => {
          const itemTime = new Date(item.createdAt).getTime();
          if (input.dateFrom && itemTime < input.dateFrom) return false;
          if (input.dateTo && itemTime > input.dateTo) return false;
          if (item.confidenceScore < input.confidenceThreshold) return false;
          if (item.processingTimeMs < input.processingTimeMin) return false;
          if (item.processingTimeMs > input.processingTimeMax) return false;
          return true;
        });

        if (filtered.length === 0) {
          return {
            totalProcessed: 0,
            avgConfidence: 0,
            avgProcessingTime: 0,
            minConfidence: 0,
            maxConfidence: 0,
          };
        }

        const avgConfidence = Math.round(
          filtered.reduce((sum, item) => sum + item.confidenceScore, 0) / filtered.length
        );
        const avgProcessingTime = Math.round(
          filtered.reduce((sum, item) => sum + item.processingTimeMs, 0) / filtered.length
        );
        const minConfidence = Math.min(...filtered.map((item) => item.confidenceScore));
        const maxConfidence = Math.max(...filtered.map((item) => item.confidenceScore));

        return {
          totalProcessed: filtered.length,
          avgConfidence,
          avgProcessingTime,
          minConfidence,
          maxConfidence,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch analytics",
        });
      }
    }),

  /**
   * Get confidence score distribution with filtering
   */
  getConfidenceDistribution: protectedProcedure
    .input(
      z.object({
        dateFrom: z.number().optional(),
        dateTo: z.number().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        let history = await getUserDiacritizationHistory(ctx.user.id, 1000, 0);

        // Apply date filters
        history = history.filter((item) => {
        const itemTime = new Date(item.createdAt).getTime();
        if (input.dateFrom && itemTime < input.dateFrom) return false;
        if (input.dateTo && itemTime > input.dateTo) return false;
        return true;
      });

        // Group by confidence ranges
        const ranges = {
        "0-20": 0,
        "21-40": 0,
        "41-60": 0,
        "61-80": 0,
        "81-100": 0,
      };

        history.forEach((item) => {
        const score = item.confidenceScore;
        if (score <= 20) ranges["0-20"]++;
        else if (score <= 40) ranges["21-40"]++;
        else if (score <= 60) ranges["41-60"]++;
        else if (score <= 80) ranges["61-80"]++;
        else ranges["81-100"]++;
      });

        return Object.entries(ranges).map(([range, count]) => ({
        range,
        count,
      }));
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to fetch confidence distribution",
      });
    }
  }),

  /**
   * Get processing time trends with filtering
   */
  getProcessingTimeTrends: protectedProcedure
    .input(
      z.object({
        days: z.number().int().positive().default(30),
        dateFrom: z.number().optional(),
        dateTo: z.number().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const history = await getUserDiacritizationHistory(ctx.user.id, 1000, 0);

        // Group by date
        const trends: Record<string, { count: number; totalTime: number }> = {};
        const now = new Date();

        history.forEach((item) => {
          const itemDate = new Date(item.createdAt);
          const itemTime = itemDate.getTime();
          const daysDiff = Math.floor((now.getTime() - itemTime) / (1000 * 60 * 60 * 24));

          if (daysDiff <= input.days && (!input.dateFrom || itemTime >= input.dateFrom) && (!input.dateTo || itemTime <= input.dateTo)) {
            const dateStr = itemDate.toISOString().split("T")[0];
            if (!trends[dateStr]) {
              trends[dateStr] = { count: 0, totalTime: 0 };
            }
            trends[dateStr].count++;
            trends[dateStr].totalTime += item.processingTimeMs;
          }
        });

        return Object.entries(trends)
          .map(([date, data]) => ({
            date,
            avgTime: Math.round(data.totalTime / data.count),
            count: data.count,
          }))
          .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch processing time trends",
        });
      }
    }),

  /**
   * Get mode usage statistics
   */
  getModeUsage: protectedProcedure.query(async ({ ctx }) => {
    try {
      const history = await getUserDiacritizationHistory(ctx.user.id, 1000, 0);

      // Count results by mode (we'll count based on which aeraab fields are non-empty)
      const modeCount = {
        full: 0,
        partial: 0,
        minimal: 0,
      };

        history.forEach((item) => {
        // This is a simplified approach - in real usage, you might want to store the mode in the results table
        modeCount.full++;
      });

      const total = modeCount.full + modeCount.partial + modeCount.minimal;

      return {
        full: { count: modeCount.full, percentage: total > 0 ? Math.round((modeCount.full / total) * 100) : 0 },
        partial: { count: modeCount.partial, percentage: total > 0 ? Math.round((modeCount.partial / total) * 100) : 0 },
        minimal: { count: modeCount.minimal, percentage: total > 0 ? Math.round((modeCount.minimal / total) * 100) : 0 },
      };
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to fetch mode usage",
      });
    }
  }),
});
