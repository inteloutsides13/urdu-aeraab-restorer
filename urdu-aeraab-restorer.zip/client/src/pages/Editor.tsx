import { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Copy, Download, RotateCcw, History, Clipboard, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";

type AeraabMode = "full" | "partial" | "minimal";

interface DiacritizationResult {
  id: number;
  inputText: string;
  fullAeraab: string;
  partialAeraab: string;
  minimalAeraab: string;
  confidenceScore: number;
  processingTimeMs: number;
  notes: string;
}

export default function Editor() {
  const { user } = useAuth();
  const [inputText, setInputText] = useState("");
  const [selectedMode, setSelectedMode] = useState<AeraabMode>("full");
  const [result, setResult] = useState<DiacritizationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [userRating, setUserRating] = useState<Record<number, number>>({});
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const submitRatingMutation = trpc.ratings.submitRating.useMutation({
    onSuccess: () => {
      toast.success("Rating submitted!");
    },
    onError: () => {
      toast.error("Failed to submit rating");
    },
  });

  const diacritizeMutation = trpc.diacritization.process.useMutation({
    onSuccess: (data) => {
      setResult(data);
      setIsLoading(false);
      toast.success("Text diacritized successfully!");
    },
    onError: (error) => {
      setIsLoading(false);
      toast.error(error.message || "Failed to diacritize text");
    },
  });

  const handleRating = (resultId: number, rating: number) => {
    setUserRating((prev) => ({ ...prev, [resultId]: rating }));
    submitRatingMutation.mutate({ resultId, rating });
  };

  const handleDiacritize = async () => {
    if (!inputText.trim()) {
      toast.error("Please enter some Urdu text");
      return;
    }

    setIsLoading(true);
    await diacritizeMutation.mutateAsync({ text: inputText });
  };

  const handleCopy = () => {
    if (!result) return;

    let textToCopy = "";
    if (selectedMode === "full") {
      textToCopy = result.fullAeraab;
    } else if (selectedMode === "partial") {
      textToCopy = result.partialAeraab;
    } else {
      textToCopy = result.minimalAeraab;
    }

    navigator.clipboard.writeText(textToCopy);
    toast.success("Copied to clipboard!");
  };

  const handleDownload = async (format: "txt" | "html") => {
    if (!result) return;

    try {
      const utils = trpc.useUtils();
      const exportResult = format === "txt"
        ? await utils.export.toPlainText.fetch({
            id: result.id,
            mode: selectedMode,
          })
        : await utils.export.toHtml.fetch({
            id: result.id,
            mode: selectedMode,
          });

      const element = document.createElement("a");
      const file = new Blob([exportResult.content], {
        type: exportResult.mimeType,
      });
      element.href = URL.createObjectURL(file);
      element.download = exportResult.filename;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);

      toast.success(`Downloaded as ${format.toUpperCase()}`);
    } catch (error) {
      toast.error("Failed to download file");
    }
  };

  const handleClear = () => {
    setInputText("");
    setResult(null);
    inputRef.current?.focus();
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setInputText(text);
      inputRef.current?.focus();
      toast.success("Text pasted from clipboard");
    } catch (error) {
      toast.error("Failed to read clipboard");
    }
  };

  const getOutputText = () => {
    if (!result) return "";
    if (selectedMode === "full") return result.fullAeraab;
    if (selectedMode === "partial") return result.partialAeraab;
    return result.minimalAeraab;
  };

  const modeLabels: Record<AeraabMode, string> = {
    full: "Full Aeraab",
    partial: "Partial Aeraab",
    minimal: "Minimal Aeraab",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-card/20 dark:from-background dark:via-background dark:to-card/10">
      {/* Header */}
      <div className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">اردو اعراب</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Urdu Aeraab Diacritization Engine
              </p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowHistory(!showHistory)}
              className="gap-2"
            >
              <History className="w-4 h-4" />
              History
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Editor */}
          <div className="lg:col-span-2 space-y-6">
            {/* Input Section */}
            <Card className="p-6 border border-border/50">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Input Text (بغیر اعراب)
                  </label>
                  <textarea
                    ref={inputRef}
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    placeholder="اپنا اردو متن یہاں درج کریں..."
                    className="w-full h-48 p-4 bg-card text-card-foreground border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring resize-none text-lg leading-relaxed"
                    dir="rtl"
                    style={{ fontFamily: "'Noto Nastaliq Urdu', serif" }}
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{inputText.length} characters</span>
                  <span>{inputText.split(/\s+/).filter(Boolean).length} words</span>
                </div>

                <div className="flex gap-2 flex-wrap">
                  <Button
                    onClick={handleDiacritize}
                    disabled={isLoading || !inputText.trim()}
                    className="flex-1 gap-2"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Add Aeraab"
                    )}
                  </Button>
                  <Button
                    onClick={handlePaste}
                    variant="outline"
                    className="gap-2"
                  >
                    <Clipboard className="w-4 h-4" />
                    Paste
                  </Button>
                  <Button
                    onClick={handleClear}
                    variant="outline"
                    className="gap-2"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Clear
                  </Button>
                </div>
              </div>
            </Card>

            {/* Output Section */}
            {result && (
              <Card className="p-6 border border-border/50 space-y-4">
                <div className="space-y-3">
                  <label className="block text-sm font-medium text-foreground">
                    Output Text (اعراب کے ساتھ)
                  </label>

                  {/* Mode Selector */}
                  <div className="flex gap-2 flex-wrap">
                    {(["full", "partial", "minimal"] as const).map((mode) => (
                      <Button
                        key={mode}
                        onClick={() => setSelectedMode(mode)}
                        variant={selectedMode === mode ? "default" : "outline"}
                        size="sm"
                        className="text-xs"
                      >
                        {modeLabels[mode]}
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Output Display */}
                <div className="bg-card border border-input rounded-lg p-4 min-h-48 overflow-auto">
                  <pre
                    className="text-lg text-card-foreground font-mono whitespace-pre"
                    dir="rtl"
                    style={{ fontFamily: "'Noto Nastaliq Urdu', monospace", lineHeight: "1.6" }}
                  >
                    {getOutputText()}
                  </pre>
                </div>

                {/* Confidence Score */}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Confidence Score:</span>
                  <div className="flex items-center gap-2">
                    <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-blue-600 transition-all"
                        style={{ width: `${result.confidenceScore}%` }}
                      />
                    </div>
                    <span className="font-semibold text-foreground w-12 text-right">
                      {result.confidenceScore}%
                    </span>
                  </div>
                </div>

                {/* Rating Component */}
                <div className="flex items-center justify-between text-sm pt-2">
                  <span className="text-muted-foreground">Rate this result:</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => handleRating(result.id, star)}
                        className="text-xl transition-colors hover:text-yellow-400"
                      >
                        {star <= (userRating?.[result.id] || 0) ? "★" : "☆"}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Export Buttons */}
                <div className="flex gap-2 pt-2">
                  <Button
                    onClick={handleCopy}
                    variant="outline"
                    size="sm"
                    className="flex-1 gap-2"
                  >
                    <Copy className="w-4 h-4" />
                    Copy
                  </Button>
                  <Button
                    onClick={() => handleDownload("txt")}
                    variant="outline"
                    size="sm"
                    className="gap-2"
                  >
                    <Download className="w-4 h-4" />
                    TXT
                  </Button>
                  <Button
                    onClick={() => handleDownload("html")}
                    variant="outline"
                    size="sm"
                    className="gap-2"
                  >
                    <Download className="w-4 h-4" />
                    HTML
                  </Button>
                </div>
              </Card>
            )}
          </div>

          {/* Sidebar - History */}
          {showHistory && (
            <div className="lg:col-span-1">
              <HistoryPanel userId={user?.id} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function HistoryPanel({ userId }: { userId?: number }) {
  const { data: history, isLoading, refetch } = trpc.history.list.useQuery(
    { limit: 20, offset: 0 },
    { enabled: !!userId }
  );

  const deleteMutation = trpc.history.delete.useMutation({
    onSuccess: () => {
      toast.success("Item deleted");
      refetch();
    },
    onError: () => {
      toast.error("Failed to delete item");
    },
  });

  const clearAllMutation = trpc.history.clearAll.useMutation({
    onSuccess: () => {
      toast.success("History cleared");
      refetch();
    },
    onError: () => {
      toast.error("Failed to clear history");
    },
  });

  const handleDelete = (id: number) => {
    deleteMutation.mutate({ id });
  };

  const handleClearAll = () => {
    if (confirm("Are you sure you want to clear all history? This action cannot be undone.")) {
      clearAllMutation.mutate();
    }
  };

  if (isLoading) {
    return (
      <Card className="p-6">
        <Loader2 className="w-4 h-4 animate-spin" />
      </Card>
    );
  }

  if (!history || history.length === 0) {
    return (
      <Card className="p-6 text-center text-muted-foreground">
        <p>No history yet</p>
      </Card>
    );
  }

  return (
    <Card className="p-6 space-y-3 max-h-96 overflow-y-auto">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-foreground">Recent Results</h3>
        {history && history.length > 0 && (
          <button
            onClick={handleClearAll}
            disabled={clearAllMutation.isPending}
            className="text-xs text-muted-foreground hover:text-destructive transition-colors disabled:opacity-50"
          >
            Clear All
          </button>
        )}
      </div>
      {history.map((item) => (
        <div
          key={item.id}
          className="p-3 bg-card border border-input rounded-lg hover:border-ring transition-colors group"
        >
          <div className="flex items-start justify-between gap-2">
            <p className="text-sm text-card-foreground line-clamp-2 flex-1" style={{ fontFamily: "'Noto Nastaliq Urdu', serif" }}>
              {item.inputText}
            </p>
            <button
              onClick={() => handleDelete(item.id)}
              className="text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
            <span>{item.confidenceScore}%</span>
            <span>{new Date(item.createdAt).toLocaleDateString()}</span>
          </div>
        </div>
      ))}
    </Card>
  );
}
