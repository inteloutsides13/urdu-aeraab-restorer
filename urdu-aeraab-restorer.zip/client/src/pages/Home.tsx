import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Sparkles, BookOpen, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-card/20 dark:from-background dark:via-background dark:to-card/10">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold text-foreground">اردو اعراب</div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <Button onClick={() => navigate("/editor")} className="gap-2">
                <Sparkles className="w-4 h-4" />
                Start Diacritizing
              </Button>
            ) : (
              <Button asChild>
                <a href={getLoginUrl()}>
                  Sign In
                </a>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-6 mb-16">
          <h1 className="text-5xl sm:text-6xl font-bold text-foreground leading-tight">
            Urdu Aeraab Restoration
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            AI-powered diacritization engine that automatically adds accurate Urdu aeraab (diacritical marks) to bare text with linguistic precision.
          </p>
          {isAuthenticated && (
            <Button
              size="lg"
              onClick={() => navigate("/editor")}
              className="gap-2 text-lg h-12 px-8"
            >
              <Sparkles className="w-5 h-5" />
              Start Now
              <ArrowRight className="w-5 h-5" />
            </Button>
          )}
          {!isAuthenticated && (
            <Button
              size="lg"
              asChild
              className="gap-2 text-lg h-12 px-8"
            >
              <a href={getLoginUrl()}>
                <Sparkles className="w-5 h-5" />
                Get Started
                <ArrowRight className="w-5 h-5" />
              </a>
            </Button>
          )}
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
          <Card className="p-6 border border-border/50 hover:border-ring transition-colors">
            <Zap className="w-8 h-8 text-blue-500 mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Multiple Modes
            </h3>
            <p className="text-muted-foreground">
              Full, Partial, and Minimal aeraab modes for different use cases and preferences.
            </p>
          </Card>

          <Card className="p-6 border border-border/50 hover:border-ring transition-colors">
            <BookOpen className="w-8 h-8 text-blue-500 mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Linguistic Accuracy
            </h3>
            <p className="text-muted-foreground">
              Advanced LLM with Urdu-specific linguistic rules for precise diacritization.
            </p>
          </Card>

          <Card className="p-6 border border-border/50 hover:border-ring transition-colors">
            <Sparkles className="w-8 h-8 text-blue-500 mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Easy Export
            </h3>
            <p className="text-muted-foreground">
              Download results as plain text or HTML with diacritics fully preserved.
            </p>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 mt-20 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-muted-foreground text-sm">
          <p>Urdu Aeraab Restorer - Premium AI-Powered Diacritization Engine</p>
        </div>
      </footer>
    </div>
  );
}
