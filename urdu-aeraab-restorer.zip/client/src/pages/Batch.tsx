import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Upload, Download, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function Batch() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [jobs, setJobs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  const batchListQuery = trpc.batch.list.useQuery(
    { limit: 20, offset: 0 },
    {
      enabled: !!user,
    }
  );

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (batchListQuery.data) {
      setJobs(batchListQuery.data);
      setLoading(false);
    }
  }, [batchListQuery.data]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      // In a real implementation, you would:
      // 1. Upload the file to storage
      // 2. Parse the file to count items
      // 3. Create a batch job
      // 4. Process items in the background

      toast.success("فائل اپ لوڈ ہو گئی");
      setUploading(false);
    } catch (error) {
      toast.error("فائل اپ لوڈ میں خرابی");
      setUploading(false);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-foreground/60">جاری ہے...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 rtl" dir="rtl">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">بیچ پروسیسنگ</h1>
          <p className="text-foreground/60">متعدد متون کو ایک ساتھ اعراب کریں</p>
        </div>

        {/* Upload Section */}
        <Card className="p-8 bg-card border-border mb-8">
          <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
            <Upload className="w-12 h-12 text-primary/60 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              فائل اپ لوڈ کریں
            </h3>
            <p className="text-foreground/60 mb-4">
              CSV یا TXT فائل اپ لوڈ کریں (ہر لائن ایک متن)
            </p>
            <label className="cursor-pointer">
              <input
                type="file"
                accept=".csv,.txt"
                onChange={handleFileUpload}
                disabled={uploading}
                className="hidden"
              />
              <Button
                disabled={uploading}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                {uploading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    اپ لوڈ ہو رہی ہے...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    فائل منتخب کریں
                  </>
                )}
              </Button>
            </label>
          </div>
        </Card>

        {/* Jobs List */}
        <div>
          <h2 className="text-2xl font-semibold text-foreground mb-4">
            آپ کی بیچ جابز
          </h2>
          {jobs.length === 0 ? (
            <Card className="p-8 bg-card border-border text-center">
              <p className="text-foreground/60">کوئی بیچ جاب نہیں</p>
            </Card>
          ) : (
            <div className="space-y-4">
              {jobs.map((job) => (
                <Card
                  key={job.id}
                  className="p-6 bg-card border-border hover:border-primary/50 transition-colors"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-foreground">
                        {job.filename}
                      </h3>
                      <p className="text-sm text-foreground/60">
                        {job.totalItems} متون • {job.createdAt}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-primary">
                        {job.progress}%
                      </div>
                      <p className="text-xs text-foreground/60">
                        {job.processedItems}/{job.totalItems}
                      </p>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="w-full h-2 bg-background rounded-full overflow-hidden mb-4">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{ width: `${job.progress}%` }}
                    />
                  </div>

                  {/* Status and Actions */}
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-sm font-medium px-3 py-1 rounded-full ${
                        job.status === "completed"
                          ? "bg-green-500/20 text-green-600"
                          : job.status === "processing"
                          ? "bg-blue-500/20 text-blue-600"
                          : job.status === "failed"
                          ? "bg-red-500/20 text-red-600"
                          : "bg-yellow-500/20 text-yellow-600"
                      }`}
                    >
                      {job.status === "completed"
                        ? "مکمل"
                        : job.status === "processing"
                        ? "جاری ہے"
                        : job.status === "failed"
                        ? "ناکام"
                        : "زیرِ التوا"}
                    </span>
                    <div className="flex gap-2">
                      {job.resultsUrl && (
                      <a href={job.resultsUrl} download>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-border text-foreground hover:bg-background"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          ڈاؤن لوڈ
                        </Button>
                      </a>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-border text-foreground hover:bg-background"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
