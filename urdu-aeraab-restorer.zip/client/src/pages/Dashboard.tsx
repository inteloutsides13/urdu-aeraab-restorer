import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, BarChart3, TrendingUp, Zap, Filter, X } from "lucide-react";
import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  // Filter states
  const [dateRange, setDateRange] = useState({ from: "", to: "" });
  const [confidenceThreshold, setConfidenceThreshold] = useState(0);
  const [modeFilter, setModeFilter] = useState<"all" | "full" | "partial" | "minimal">("all");
  const [processingTimeRange, setProcessingTimeRange] = useState({ min: 0, max: 10000 });

  const statsQuery = trpc.analytics.getStats.useQuery(
    {
      dateFrom: dateRange.from ? new Date(dateRange.from).getTime() : undefined,
      dateTo: dateRange.to ? new Date(dateRange.to).getTime() : undefined,
      confidenceThreshold,
      mode: modeFilter !== "all" ? modeFilter : undefined,
      processingTimeMin: processingTimeRange.min,
      processingTimeMax: processingTimeRange.max,
    },
    {
      enabled: !!user,
    }
  );

  const confidenceQuery = trpc.analytics.getConfidenceDistribution.useQuery(
    {
      dateFrom: dateRange.from ? new Date(dateRange.from).getTime() : undefined,
      dateTo: dateRange.to ? new Date(dateRange.to).getTime() : undefined,
    },
    {
      enabled: !!user,
    }
  );

  const trendsQuery = trpc.analytics.getProcessingTimeTrends.useQuery(
    {
      days: 30,
      dateFrom: dateRange.from ? new Date(dateRange.from).getTime() : undefined,
      dateTo: dateRange.to ? new Date(dateRange.to).getTime() : undefined,
    },
    {
      enabled: !!user,
    }
  );

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (statsQuery.data) {
      setStats(statsQuery.data);
      setLoading(false);
    }
  }, [statsQuery.data]);

  const handleResetFilters = () => {
    setDateRange({ from: "", to: "" });
    setConfidenceThreshold(0);
    setModeFilter("all");
    setProcessingTimeRange({ min: 0, max: 10000 });
  };

  const hasActiveFilters =
    dateRange.from ||
    dateRange.to ||
    confidenceThreshold > 0 ||
    modeFilter !== "all" ||
    processingTimeRange.min > 0 ||
    processingTimeRange.max < 10000;

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-foreground/60">جاری ہے...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 rtl" dir="rtl">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">تجزیات ڈیش بورڈ</h1>
          <p className="text-foreground/60">آپ کی اعراب کی کارکردگی کا تفصیلی جائزہ</p>
        </div>

        {/* Filter Toggle */}
        <div className="mb-6 flex gap-2">
          <Button
            onClick={() => setShowFilters(!showFilters)}
            variant="outline"
            className="gap-2 border-border text-foreground hover:bg-background"
          >
            <Filter className="w-4 h-4" />
            فلٹرز
            {hasActiveFilters && (
              <span className="ml-2 px-2 py-0.5 bg-primary text-primary-foreground text-xs rounded-full">
                {[
                  dateRange.from,
                  dateRange.to,
                  confidenceThreshold > 0,
                  modeFilter !== "all",
                  processingTimeRange.min > 0,
                  processingTimeRange.max < 10000,
                ].filter(Boolean).length}
              </span>
            )}
          </Button>
          {hasActiveFilters && (
            <Button
              onClick={handleResetFilters}
              variant="outline"
              size="sm"
              className="gap-2 border-border text-foreground hover:bg-background"
            >
              <X className="w-4 h-4" />
              صاف کریں
            </Button>
          )}
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <Card className="p-6 bg-card border-border mb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Date Range */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  شروع کی تاریخ
                </label>
                <input
                  type="date"
                  value={dateRange.from}
                  onChange={(e) => setDateRange({ ...dateRange, from: e.target.value })}
                  className="w-full px-3 py-2 bg-background border border-input rounded-lg text-foreground"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  اختتام کی تاریخ
                </label>
                <input
                  type="date"
                  value={dateRange.to}
                  onChange={(e) => setDateRange({ ...dateRange, to: e.target.value })}
                  className="w-full px-3 py-2 bg-background border border-input rounded-lg text-foreground"
                />
              </div>

              {/* Confidence Threshold */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  اعتماد کی حد: {confidenceThreshold}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={confidenceThreshold}
                  onChange={(e) => setConfidenceThreshold(Number(e.target.value))}
                  className="w-full"
                />
              </div>

              {/* Mode Filter */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  اعراب موڈ
                </label>
                <select
                  value={modeFilter}
                  onChange={(e) =>
                    setModeFilter(e.target.value as "all" | "full" | "partial" | "minimal")
                  }
                  className="w-full px-3 py-2 bg-background border border-input rounded-lg text-foreground"
                >
                  <option value="all">تمام</option>
                  <option value="full">مکمل</option>
                  <option value="partial">جزوی</option>
                  <option value="minimal">کم سے کم</option>
                </select>
              </div>

              {/* Processing Time Range */}
              <div className="lg:col-span-2">
                <label className="block text-sm font-medium text-foreground mb-2">
                  پروسیسنگ وقت: {processingTimeRange.min}ms - {processingTimeRange.max}ms
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="0"
                    value={processingTimeRange.min}
                    onChange={(e) =>
                      setProcessingTimeRange({
                        ...processingTimeRange,
                        min: Number(e.target.value),
                      })
                    }
                    placeholder="کم سے کم"
                    className="flex-1 px-3 py-2 bg-background border border-input rounded-lg text-foreground"
                  />
                  <input
                    type="number"
                    min="0"
                    max="10000"
                    value={processingTimeRange.max}
                    onChange={(e) =>
                      setProcessingTimeRange({
                        ...processingTimeRange,
                        max: Number(e.target.value),
                      })
                    }
                    placeholder="زیادہ سے زیادہ"
                    className="flex-1 px-3 py-2 bg-background border border-input rounded-lg text-foreground"
                  />
                </div>
              </div>
            </div>
          </Card>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {/* Total Processed */}
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-foreground/60 mb-2">کل متن</p>
                <p className="text-3xl font-bold text-foreground">
                  {stats?.totalProcessed || 0}
                </p>
              </div>
              <BarChart3 className="w-8 h-8 text-primary/60" />
            </div>
          </Card>

          {/* Average Confidence */}
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-foreground/60 mb-2">اوسط اعتماد</p>
                <p className="text-3xl font-bold text-foreground">
                  {stats?.avgConfidence || 0}%
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-500/60" />
            </div>
          </Card>

          {/* Average Processing Time */}
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-foreground/60 mb-2">اوسط وقت</p>
                <p className="text-3xl font-bold text-foreground">
                  {stats?.avgProcessingTime || 0}ms
                </p>
              </div>
              <Zap className="w-8 h-8 text-yellow-500/60" />
            </div>
          </Card>

          {/* Confidence Range */}
          <Card className="p-6 bg-card border-border">
            <div>
              <p className="text-sm text-foreground/60 mb-2">اعتماد کی حد</p>
              <p className="text-lg font-semibold text-foreground">
                {stats?.minConfidence || 0}% - {stats?.maxConfidence || 0}%
              </p>
            </div>
          </Card>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Confidence Distribution */}
          <Card className="p-6 bg-card border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">اعتماد کی تقسیم</h2>
            <div className="space-y-3">
              {confidenceQuery.data?.map((item: any) => (
                <div key={item.range} className="flex items-center gap-4">
                  <span className="text-sm text-foreground/60 w-12">{item.range}</span>
                  <div className="flex-1 h-2 bg-background rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all"
                      style={{
                        width: `${Math.min(
                          (item.count /
                            (confidenceQuery.data?.reduce((sum: number, d: any) => sum + d.count, 0) ||
                              1)) *
                            100,
                          100
                        )}%`,
                      }}
                    />
                  </div>
                  <span className="text-sm font-medium text-foreground w-8">{item.count}</span>
                </div>
              ))}
            </div>
          </Card>

          {/* Processing Time Trends */}
          <Card className="p-6 bg-card border-border">
            <h2 className="text-xl font-semibold text-foreground mb-4">
              وقت کا رجحان (آخری 30 دن)
            </h2>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {trendsQuery.data?.slice(-7).map((item: any) => (
                <div key={item.date} className="flex items-center justify-between text-sm">
                  <span className="text-foreground/60">{item.date}</span>
                  <span className="font-medium text-foreground">
                    {item.avgTime}ms ({item.count} متن)
                  </span>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-4 justify-center">
          <Button
            onClick={() => navigate("/editor")}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            نیا اعراب شروع کریں
          </Button>
          <Button
            onClick={() => navigate("/batch")}
            variant="outline"
            className="border-border text-foreground hover:bg-background"
          >
            بیچ پروسیسنگ
          </Button>
        </div>
      </div>
    </div>
  );
}
