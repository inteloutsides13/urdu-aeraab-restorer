# Urdu Aeraab Restorer - Project TODO

## Database & Schema
- [x] Create diacritization_results table with input, output, mode, confidence, timestamp
- [x] Create session_history table with user_id, result_id, created_at
- [x] Add indexes for efficient history queries

## Backend - tRPC Procedures
- [x] Create diacritize.process procedure with LLM integration
- [x] Create diacritize.processMultipleModes procedure (full, partial, minimal)
- [x] Create history.list procedure to fetch user's past diacritizations
- [x] Create history.delete procedure to remove individual history items
- [x] Create export.toPlainText procedure
- [x] Create export.toHtml procedure
- [x] Add confidence scoring logic to diacritization results

## Backend - LLM Integration
- [x] Develop comprehensive Urdu linguistic system prompt
- [x] Implement LLM invocation with structured JSON response format
- [x] Add error handling and fallback logic for LLM failures
- [x] Test diacritization accuracy with sample Urdu texts

## Frontend - RTL Layout & Styling
- [x] Configure Tailwind CSS for RTL-first design (direction: rtl)
- [x] Import and apply Noto Nastaliq Urdu font via Google Fonts
- [x] Create dark theme color palette (premium dark aesthetic)
- [x] Build base layout with ChatGPT-style structure
- [x] Add smooth transitions and animations throughout

## Frontend - Main Editor Component
- [x] Create RTL textarea for bare Urdu text input
- [x] Add character count and word count display
- [x] Implement real-time input validation
- [x] Add paste button for easy text insertion
- [x] Style input area with premium dark theme

## Frontend - Output Display & Comparison
- [x] Create side-by-side comparison view (input vs output)
- [x] Build output display with proper Urdu diacritics rendering
- [x] Implement mode selector (Full, Partial, Minimal aeraab)
- [x] Add confidence score visualization (percentage indicator)
- [x] Create visual distinction between different aeraab modes

## Frontend - Copy & Export Features
- [x] Implement copy-to-clipboard button for diacritized text
- [x] Create export-to-plaintext functionality
- [x] Create export-to-HTML functionality with diacritics preservation
- [x] Add download button for exported files
- [x] Show success toast notifications on copy/export

## Frontend - Session History
- [x] Create history sidebar/panel showing past diacritizations
- [x] Implement history item click to restore previous result
- [x] Add delete button for individual history items
- [x] Show timestamp and preview text for each history item
- [x] Add clear-all-history option with confirmation

## Frontend - Processing & Loading States
- [x] Add loading spinner during LLM processing
- [x] Implement estimated time display
- [x] Add error state with retry button
- [x] Show user-friendly error messages for failures

## Frontend - Responsive Design
- [x] Test layout on mobile devices (RTL-first)
- [x] Ensure textarea and buttons are touch-friendly
- [x] Verify font rendering on different screen sizes
- [x] Test history panel visibility on small screens

## Testing & Validation
- [x] Write vitest tests for diacritization procedure
- [x] Write vitest tests for history management procedures
- [x] Write vitest tests for export functionality
- [x] Test Urdu text rendering across browsers
- [x] Manual testing of all aeraab modes

## Deployment & Polish
- [x] Verify environment variables are properly set
- [x] Test rate limiting and performance
- [x] Optimize LLM response times
- [x] Add analytics tracking (optional)
- [x] Create user-facing documentation/help

## Known Issues & Blockers
- storageProxy.ts TypeScript error (framework-level, not affecting functionality)

## Completed Items
- Database schema with diacritization_results and session_history tables
- Backend tRPC procedures for diacritization, history, and export
- LLM integration with Urdu linguistic system prompt
- RTL-first dark theme with Noto Nastaliq Urdu font
- Editor page with input/output display and mode selection
- Landing page with feature overview
- Copy-to-clipboard and export functionality
- History panel with past diacritizations


## NEW FEATURES - Batch Processing
- [ ] Create batch_jobs table for tracking bulk processing tasks
- [ ] Add batch.upload procedure to handle file uploads (CSV/TXT)
- [ ] Add batch.process procedure to process multiple texts
- [ ] Add batch.list procedure to retrieve user's batch jobs
- [ ] Create batch processing UI with file upload
- [ ] Implement progress tracking for batch jobs
- [ ] Add batch results download functionality

## NEW FEATURES - Accuracy Dashboard
- [ ] Create analytics.getStats procedure for confidence/processing time stats
- [ ] Build Dashboard page with statistics visualization
- [ ] Add confidence score distribution chart
- [ ] Add processing time trends chart
- [ ] Add user satisfaction rating system
- [ ] Display total texts processed and average metrics
- [ ] Add filters for date range and mode selection

## NEW FEATURES - History Cleanup
- [ ] Add history.clearAll procedure with user confirmation
- [ ] Add clear-all button to history panel
- [ ] Implement confirmation dialog before clearing
- [ ] Add success notification after clearing
- [ ] Add option to export history before clearing


## PHASE 2 ENHANCEMENTS

### Background Job Processing
- [ ] Add queue_jobs table to database schema for job tracking (optional - batch works synchronously)
- [ ] Create async job processor service using Node.js worker threads (future enhancement)
- [ ] Implement job status tracking (pending, processing, completed, failed) (future enhancement)
- [ ] Add WebSocket support for real-time job progress updates (future enhancement)
- [ ] Create job retry logic with exponential backoff (future enhancement)
- [ ] Implement job timeout and cleanup mechanisms (future enhancement)
- [ ] Add background job processor to batch router (future enhancement)

### Advanced Analytics Filtering
- [x] Add date range picker component to Dashboard
- [x] Add confidence threshold slider filter
- [x] Add aeraab mode filter (full/partial/minimal)
- [x] Add processing time range filter
- [x] Implement filter state persistence in URL params
- [x] Create filtered statistics recalculation procedures
- [x] Add "Apply Filters" and "Reset Filters" buttons
- [x] Update analytics queries to support filtering

### User Satisfaction Ratings
- [x] Add result_ratings table to database schema
- [x] Create rating UI component (1-5 stars)
- [x] Implement rating submission procedure in tRPC
- [ ] Add rating display in history panel
- [x] Create rating statistics in analytics (average, distribution)
- [ ] Add rating filter to analytics dashboard
- [ ] Show most/least rated results in dashboard
- [x] Add rating validation and error handling

### Layout-Preserving Output Formatting
- [x] Modify LLM system prompt to preserve line breaks and spacing
- [x] Update diacritization output to maintain original formatting
- [x] Preserve paragraph structure and indentation
- [x] Keep original line endings (LF/CRLF)
- [x] Add whitespace preservation in export functions
- [x] Create pre-formatted display for output text using <pre> tag
- [x] Test with multi-line and formatted Urdu texts
- [x] Ensure HTML export preserves formatting with <pre> wrapper
- [x] Ensure TXT export preserves formatting exactly
- [x] Add formatting preservation option to export dialog
