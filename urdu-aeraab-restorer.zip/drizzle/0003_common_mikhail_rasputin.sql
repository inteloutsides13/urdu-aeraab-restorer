CREATE TABLE `result_ratings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`resultId` int NOT NULL,
	`userId` int NOT NULL,
	`rating` int NOT NULL,
	`feedback` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `result_ratings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `result_ratings` ADD CONSTRAINT `result_ratings_resultId_diacritization_results_id_fk` FOREIGN KEY (`resultId`) REFERENCES `diacritization_results`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `result_ratings` ADD CONSTRAINT `result_ratings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;