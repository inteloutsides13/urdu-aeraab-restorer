CREATE TABLE `diacritization_results` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`inputText` text NOT NULL,
	`fullAeraab` text NOT NULL,
	`partialAeraab` text NOT NULL,
	`minimalAeraab` text NOT NULL,
	`confidenceScore` int NOT NULL DEFAULT 0,
	`processingTimeMs` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `diacritization_results_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `session_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`resultId` int NOT NULL,
	`lastAccessedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `session_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `diacritization_results` ADD CONSTRAINT `diacritization_results_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `session_history` ADD CONSTRAINT `session_history_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `session_history` ADD CONSTRAINT `session_history_resultId_diacritization_results_id_fk` FOREIGN KEY (`resultId`) REFERENCES `diacritization_results`(`id`) ON DELETE cascade ON UPDATE no action;