import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const batchJobs = mysqlTable("batch_jobs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  totalItems: int("totalItems").notNull(),
  processedItems: int("processedItems").default(0).notNull(),
  status: mysqlEnum("status", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  fileUrl: text("fileUrl"),
  resultsUrl: text("resultsUrl"),
  errorMessage: text("errorMessage"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BatchJob = typeof batchJobs.$inferSelect;
export type InsertBatchJob = typeof batchJobs.$inferInsert;

/**
 * Diacritization results table storing all processed texts and their aeraab outputs.
 */
export const diacritizationResults = mysqlTable("diacritization_results", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  /** Original bare Urdu text without diacritics */
  inputText: text("inputText").notNull(),
  /** Full aeraab output with all diacritics */
  fullAeraab: text("fullAeraab").notNull(),
  /** Partial aeraab with only ambiguous words diacritized */
  partialAeraab: text("partialAeraab").notNull(),
  /** Minimal aeraab with only essential marks */
  minimalAeraab: text("minimalAeraab").notNull(),
  /** Confidence score (0-100) indicating diacritization coverage/quality */
  confidenceScore: int("confidenceScore").notNull().default(0),
  /** Processing time in milliseconds */
  processingTimeMs: int("processingTimeMs").notNull().default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type DiacritizationResult = typeof diacritizationResults.$inferSelect;
export type InsertDiacritizationResult = typeof diacritizationResults.$inferInsert;

/**
 * Session history table for tracking user interactions and past diacritizations.
 */
export const sessionHistory = mysqlTable("session_history", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  resultId: int("resultId").notNull().references(() => diacritizationResults.id, { onDelete: "cascade" }),
  /** Last accessed timestamp for sorting */
  lastAccessedAt: timestamp("lastAccessedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SessionHistory = typeof sessionHistory.$inferSelect;
export type InsertSessionHistory = typeof sessionHistory.$inferInsert;

export const resultRatings = mysqlTable("result_ratings", {
  id: int("id").autoincrement().primaryKey(),
  resultId: int("resultId").notNull().references(() => diacritizationResults.id, { onDelete: "cascade" }),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  rating: int("rating").notNull(), // 1-5 stars
  feedback: text("feedback"), // Optional user feedback
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ResultRating = typeof resultRatings.$inferSelect;
export type InsertResultRating = typeof resultRatings.$inferInsert;
